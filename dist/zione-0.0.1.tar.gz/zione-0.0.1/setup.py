from setuptools import setup

setup(
    name="zione",
    packages=["zione"],
    version="0.0.1",
    include_package_data=True,
    install_requires=[
        "aniso8601==9.0.1",
        "click==8.0.3",
        "Flask==2.0.2",
        "Flask-JWT-Extended==4.3.1",
        "Flask-RESTful==0.3.9",
        "itsdangerous==2.0.1",
        "Jinja2==3.0.3",
        "MarkupSafe==2.0.1",
        "marshmallow==3.14.1",
        "psycopg==3.0.5",
        "PyJWT==2.3.0",
        "pytz==2021.3",
        "six==1.16.0",
        "Werkzeug==2.0.2",
    ],
)
