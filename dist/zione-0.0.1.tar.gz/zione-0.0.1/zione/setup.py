from setuptools import setup

setup(
    name='zione',
    packages=['zione'],
    version="0.0.1",
    include_package_data=True,
    install_requires=[
        'flask',
    ],
)
